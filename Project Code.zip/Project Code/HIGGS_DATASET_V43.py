# -*- coding: utf-8 -*-
"""
Created on Mon Jun 23 12:24 2025

@author: TCSEKOC
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, precision_recall_curve, confusion_matrix, matthews_corrcoef
import matplotlib.pyplot as plt
import seaborn as sns
import logging
import os
import joblib
import xgboost

# Log dosyasi ayarlari
log_file = 'log.txt'
logging.basicConfig(filename=log_file, level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Loglama fonksiyonu
def log_action(message):
    logging.info(message)
    print(message)

# XGBoost surumunu logla
log_action(f"XGBoost surumu: {xgboost.__version__}")

# Rastgele ornekleme fonksiyonu
def sample_data_consistent_chunks(data_chunks, features_chunks, targets_chunks, sample_size=100000, random_state=None, chunk_size=5000):
    all_indices = []
    total_rows = sum(len(chunk) for chunk in data_chunks)
    if sample_size > total_rows:
        sample_size = total_rows
        log_action(f"Sample size {sample_size} olarak ayarlandı, toplam satir sayisindan buyuk olamaz.")

    current_index = 0
    for i, chunk in enumerate(data_chunks):
        chunk_size_local = len(chunk)
        chunk_indices = np.random.choice(chunk_size_local, size=min(sample_size - len(all_indices), chunk_size_local), replace=False)
        global_indices = chunk_indices + current_index
        all_indices.extend(global_indices.tolist())
        current_index += chunk_size_local
        if len(all_indices) >= sample_size:
            break

    all_indices = np.array(all_indices[:sample_size])
    data_parts = []
    features_parts = []
    targets_parts = []
    for i, chunk in enumerate(data_chunks):
        start_idx = sum(len(dc) for dc in data_chunks[:i])
        end_idx = start_idx + len(chunk)
        chunk_indices = all_indices[np.logical_and(all_indices >= start_idx, all_indices < end_idx)] - start_idx
        if len(chunk_indices) > 0:
            data_parts.append(chunk.iloc[chunk_indices])
            features_parts.append(features_chunks[i].iloc[chunk_indices])
            targets_parts.append(targets_chunks[i].iloc[chunk_indices])

    data = pd.concat(data_parts, axis=0, ignore_index=True)
    features = pd.concat(features_parts, axis=0, ignore_index=True)
    targets = pd.concat(targets_parts, axis=0, ignore_index=True)

    return data, features, targets

# Grafik cizme fonksiyonu
def plot_before_after(data_before, data_after, feature, step):
    if feature not in data_after.columns:
        log_action(f"Uyari: {feature} sutunu bulunmuyor, gorsellestirme atlaniyor.")
        return
    
    data_before_vals = pd.to_numeric(data_before[feature], errors='coerce').values.reshape(-1, 1)
    data_after_vals = pd.to_numeric(data_after[feature], errors='coerce').values.reshape(-1, 1)
    
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    sns.histplot(data_before_vals.ravel(), bins=40, kde=True)
    plt.title(f'Before {step} - {feature}')
    
    plt.subplot(1, 2, 2)
    sns.histplot(data_after_vals.ravel(), bins=40, kde=True)
    plt.title(f'After {step} - {feature}')
    
    plt.tight_layout()
    plt.savefig(f'before_after_{step}_{feature}.png')
    plt.close()

# Veri dagilimini gorsellestirme fonksiyonu
def plot_feature_distributions(data, features, step='initial'):
    log_action(f"{step} veri dagilimi icin histogramlar olusturuluyor...")
    for feature in features:
        plt.figure(figsize=(8, 6))
        sns.histplot(pd.to_numeric(data[feature], errors='coerce').values.ravel(), bins=40, kde=True)
        plt.title(f'Distribution of {feature} ({step})')
        plt.xlabel(feature)
        plt.ylabel('Count')
        plt.savefig(f'distribution_{feature}_{step}.png')
        plt.close()

# Model yukleme veya egitme fonksiyonu
def load_or_train_model(model, params, X_train, y_train, X_val, y_val, model_filename):
    if os.path.exists(model_filename):
        log_action(f"{model_filename} bulundu, model yukleniyor...")
        return joblib.load(model_filename)
    else:
        log_action(f"{model_filename} bulunamadi, model egiliyor...")
        model_instance = model(**params)
        if model == XGBClassifier:
            model_instance.fit(X_train, y_train, verbose=False)
        else:
            model_instance.fit(X_train, y_train)
        joblib.dump(model_instance, model_filename)
        log_action(f"{model.__name__} modeli '{model_filename}' olarak kaydedildi.")
        return model_instance

# Grafik cizim kontrolu ve cizimi
def plot_model_graphs(model_name, n_features, X, y, model_filename):
    roc_file = f'roc_curve_{n_features}_{model_name}.png'
    pr_file = f'pr_curve_{n_features}_{model_name}.png'
    cm_file = f'confusion_matrix_{n_features}_{model_name}.png'

    # Grafiklerin varligini kontrol et
    if os.path.exists(roc_file) and os.path.exists(pr_file) and os.path.exists(cm_file):
        log_action(f"{model_name} icin {n_features} ozellik grafiklerinin tumu bulundu, cizim atlaniyor...")
        return
    else:
        log_action(f"{model_name} icin {n_features} ozellik icin eksik grafikler tespit edildi, cizim yapiliyor...")

    if os.path.exists(model_filename):
        log_action(f"{model_filename} bulundu, model yukleniyor...")
        best_model = joblib.load(model_filename)
        
        # ROC egrisi
        if not os.path.exists(roc_file):
            log_action(f"{roc_file} bulunamadi, ROC egrisi ciziliyor...")
            plt.figure(figsize=(10, 6))
            fpr, tpr, _ = roc_curve(y, best_model.predict_proba(X)[:, 1])
            plt.plot(fpr, tpr, label=f'{model_name} (AUC = {roc_auc_score(y, best_model.predict_proba(X)[:, 1]):.4f})')
            plt.plot([0, 1], [0, 1], 'k--')
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title(f'ROC Curve for {model_name} ({n_features} Features)')
            plt.legend()
            plt.savefig(roc_file)
            plt.close()
            log_action(f"{roc_file} kaydedildi.")

        # Precision-Recall egrisi
        if not os.path.exists(pr_file):
            log_action(f"{pr_file} bulunamadi, Precision-Recall egrisi ciziliyor...")
            plt.figure(figsize=(10, 6))
            precision, recall, _ = precision_recall_curve(y, best_model.predict_proba(X)[:, 1])
            plt.plot(recall, precision, label=f'{model_name} (AUC-PR = {roc_auc_score(y, best_model.predict_proba(X)[:, 1]):.4f})')
            plt.xlabel('Recall')
            plt.ylabel('Precision')
            plt.title(f'Precision-Recall Curve for {model_name} ({n_features} Features)')
            plt.legend()
            plt.savefig(pr_file)
            plt.close()
            log_action(f"{pr_file} kaydedildi.")

        # Confusion Matrix
        if not os.path.exists(cm_file):
            log_action(f"{cm_file} bulunamadi, Confusion Matrix ciziliyor...")
            plt.figure(figsize=(8, 6))
            y_pred = best_model.predict(X)
            cm = confusion_matrix(y, y_pred)
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
            plt.title(f'Confusion Matrix for {model_name} ({n_features} Features)')
            plt.ylabel('True Label')
            plt.xlabel('Predicted Label')
            plt.savefig(cm_file)
            plt.close()
            log_action(f"{cm_file} kaydedildi.")
    else:
        log_action(f"{model_filename} bulunamadi, grafikler cizilemedi.")

# 1. Veri On Isleme
def preprocess_data():
    processed_data_file = 'processed_data.pkl'
    if os.path.exists(processed_data_file):
        log_action(f"{processed_data_file} bulundu, islenmis veri yukleniyor...")
        data = joblib.load(processed_data_file)
        features = [f'feature_{i}' for i in range(1, 29)]
        return data, features

    log_action("Bolum 1: Veri On Isleme Basladi")
    chunk_size = 25000
    data_chunks = []
    features_chunks = []
    targets_chunks = []

    log_action("Veri dosyalari 'higgs_dataset.csv', 'higgs_features.csv', 'higgs_targets.csv' parcalar halinde okunuyor...")
    try:
        for chunk in pd.read_csv('higgs_dataset.csv', chunksize=chunk_size, engine='python', on_bad_lines='skip', dtype_backend='numpy_nullable'):
            data_chunks.append(chunk)
        for chunk in pd.read_csv('higgs_features.csv', chunksize=chunk_size, engine='python', on_bad_lines='skip', dtype_backend='numpy_nullable'):
            features_chunks.append(chunk)
        for chunk in pd.read_csv('higgs_targets.csv', chunksize=chunk_size, engine='python', on_bad_lines='skip', dtype_backend='numpy_nullable'):
            targets_chunks.append(chunk)
    except Exception as e:
        log_action(f"Veri okuma hatasi: {e}. Chunk size'i dusurmeyi veya dosya yapisini kontrol etmeyi deneyin.")
        exit()

    if data_chunks and len(data_chunks[0]) != len(features_chunks[0]) or len(data_chunks[0]) != len(targets_chunks[0]):
        log_action("Uyari: Ilk parca satir sayilari eslesmiyor!")
        exit()
    else:
        total_rows = sum(len(chunk) for chunk in data_chunks)
        log_action(f"Veri okundu. Toplam satir sayisi: {total_rows}, Sutun sayisi (dataset): {len(data_chunks[0].columns)}, (features): {len(features_chunks[0].columns)}, (targets): {len(targets_chunks[0].columns)}")

    if data_chunks:
        data, features, targets = sample_data_consistent_chunks(data_chunks, features_chunks, targets_chunks, sample_size=100000, random_state=np.random.randint(0, 1000), chunk_size=5000)
        log_action(f"Rastgele {len(data)} satir ve eslesen veriler secildi. Yeni satir sayisi: {len(data)}")
    else:
        log_action("Veri parcalari bos. Islem durduruldu.")
        exit()

    data_before = pd.concat([features, targets.iloc[:, 0].rename('target')], axis=1)
    data = data_before.copy()
    data.columns = ['target'] + [f'feature_{i}' for i in range(1, 29)]
    log_action(f"Hedef degiskeni ozelliklerle birlestirildi. Sutun sayisi: {len(data.columns)}")

    data['target'] = (data['target'] > 0.5).astype(int)
    log_action(f"Hedef degisken benzersiz degerler: {np.unique(data['target'])}")

    # Veri dagilimini gorsellestir
    features = [f'feature_{i}' for i in range(1, 29)]
    plot_feature_distributions(data, features, 'initial')

    log_action("Aykiri deger analizi (IQR yontemi, 3.0*IQR) baslatiliyor...")
    def detect_outliers_chunk(df, iqr_multiplier=3.0):
        outliers = pd.DataFrame()
        outlier_counts = {}
        for column in features:
            Q1 = df[column].quantile(0.25)
            Q3 = df[column].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - iqr_multiplier * IQR
            upper_bound = Q3 + iqr_multiplier * IQR
            outliers[column] = (df[column] < lower_bound) | (df[column] > upper_bound)
            outlier_counts[column] = outliers[column].sum()
        log_action(f"Ozellik bazinda aykiri deger sayilari: {outlier_counts}")
        return outliers.any(axis=1)

    outliers = detect_outliers_chunk(data, iqr_multiplier=3.0)
    log_action(f"Aykiri deger tespit edildi: {outliers.sum()} adet aykiri deger bulundu.")

    for feature in features[:15]:  # Ilk 15 ozellik icin grafik
        plot_before_after(data_before, data, feature, 'outlier_removal')

    for column in features:
        Q1 = data[column].quantile(0.25)
        Q3 = data[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 3.0 * IQR
        upper_bound = Q3 + 3.0 * IQR
        data.loc[data[column] < lower_bound, column] = lower_bound
        data.loc[data[column] > upper_bound, column] = upper_bound
    log_action("Aykiri degerler sinir degerlerle degistirildi.")

    log_action("Ozellik olcekleme (MinMaxScaler) baslatiliyor...")
    data_before_scaling = data.copy()
    scaler = MinMaxScaler()
    data[features] = scaler.fit_transform(data[features])

    for feature in features[:15]:  # Ilk 15 ozellik icin grafik
        plot_before_after(data_before_scaling, data, feature, 'scaling')

    log_action("Ozellikler [0, 1] araligina olceklendirildi.")
    log_action("Bolum 1: Veri On Isleme Tamamlandi")

    # Islenmis veriyi kaydet
    joblib.dump(data, processed_data_file)
    log_action(f"Islenmis veri {processed_data_file} olarak kaydedildi.")

    return data, features

# 2. Ozellik Secimi ve Modelleme
def run_model(model_name, n_features, data, features):
    log_action(f"{n_features} ozellik ile {model_name} modeli icin islem baslatiliyor...")
    
    # Outer ve Inner CV ayarlari
    outer_cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    inner_cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)

    # Hiperparametre kriterleri
    param_grids = {
        'KNN': [{'n_neighbors': n} for n in range(3, 12)],
        'SVM': [{'C': C, 'kernel': kernel, 'probability': True} for C in [0.1, 1, 10] for kernel in ['linear', 'rbf']],
        'MLP': [{'hidden_layer_sizes': size, 'activation': act} for size in [(50,), (100,)] for act in ['relu', 'tanh']],
        'XGBoost': [{'max_depth': d, 'learning_rate': lr, 'n_estimators': 100} for d in [3, 5] for lr in [0.01, 0.1]]
    }

    # Modeller
    models = {
        'KNN': KNeighborsClassifier,
        'SVM': SVC,
        'MLP': MLPClassifier,
        'XGBoost': XGBClassifier
    }

    def nested_cv(X, y, model, param_grid, feature_count, model_name):
        outer_scores = {'accuracy': [], 'precision': [], 'recall': [], 'f1': [], 'roc_auc': [], 'mcc': []}
        param_scores = {}  # Her hiperparametre kombinasyonu icin ortalama skoru sakla
        model_filename = f'{model_name.lower()}_model_{feature_count}.pkl'

        # Model dosyasını kontrol et
        if os.path.exists(model_filename):
            log_action(f"{model_filename} bulundu, yalnizca performans degerleniyor...")
            best_model = joblib.load(model_filename)
            for fold_idx, (train_idx, test_idx) in enumerate(outer_cv.split(X, y)):
                log_action(f"{model_name} icin dis CV dongu {fold_idx + 1}/{outer_cv.n_splits}")
                X_test = X[test_idx]
                y_test = y[test_idx]
                y_pred = best_model.predict(X_test)
                y_proba = best_model.predict_proba(X_test)[:, 1]
                outer_scores['accuracy'].append(accuracy_score(y_test, y_pred))
                outer_scores['precision'].append(precision_score(y_test, y_pred, average='weighted', zero_division=0))
                outer_scores['recall'].append(recall_score(y_test, y_pred, average='weighted', zero_division=0))
                outer_scores['f1'].append(f1_score(y_test, y_pred, average='weighted', zero_division=0))
                outer_scores['roc_auc'].append(roc_auc_score(y_test, y_proba))
                outer_scores['mcc'].append(matthews_corrcoef(y_test, y_pred))
            return {key: np.mean(value) for key, value in outer_scores.items()}, None

        log_action(f"{model_filename} bulunamadi, tum dis ve ic CV donguleri calistiriliyor...")
        try:
            # Tum dis CV dongulerini tamamla
            for fold_idx, (train_idx, test_idx) in enumerate(outer_cv.split(X, y)):
                log_action(f"{model_name} icin dis CV dongu {fold_idx + 1}/{outer_cv.n_splits}")
                X_train, X_test = X[train_idx], X[test_idx]
                y_train, y_test = y[train_idx], y[test_idx]

                # Ic CV ile her hiperparametre kombinasyonunu degerlendir
                for params in param_grid:
                    param_key = str(params)  # Hiperparametreleri string olarak sakla
                    if param_key not in param_scores:
                        param_scores[param_key] = []
                    log_action(f"{feature_count} ozellik ile Inner CV params: {params}")
                    scores = []
                    for inner_train, inner_val in inner_cv.split(X_train, y_train):
                        X_inner_train, X_inner_val = X_train[inner_train], X_train[inner_val]
                        y_inner_train, y_inner_val = y_train[inner_train], y_train[inner_val]
                        X_inner_train_split, X_inner_val_split, y_inner_train_split, y_inner_val_split = train_test_split(
                            X_inner_train, y_inner_train, test_size=0.2, random_state=42
                        )
                        model_instance = model(**params)
                        if model == XGBClassifier:
                            model_instance.fit(X_inner_train_split, y_inner_train_split, verbose=False)
                        else:
                            model_instance.fit(X_inner_train_split, y_inner_train_split)
                        scores.append(model_instance.score(X_inner_val, y_inner_val))
                    param_scores[param_key].append(np.mean(scores))

                # Dis CV icin gecici model egitimi ve performans
                best_params_fold = max(param_scores, key=lambda k: np.mean(param_scores[k]))
                best_params_dict = eval(best_params_fold)  # String'den dict'e cevir
                model_instance = model(**best_params_dict)
                X_train_split, X_val_split, y_train_split, y_val_split = train_test_split(X_train, y_train, test_size=0.2, random_state=42)
                if model == XGBClassifier:
                    model_instance.fit(X_train_split, y_train_split, verbose=False)
                else:
                    model_instance.fit(X_train_split, y_train_split)
                y_pred = model_instance.predict(X_test)
                y_proba = model_instance.predict_proba(X_test)[:, 1]
                outer_scores['accuracy'].append(accuracy_score(y_test, y_pred))
                outer_scores['precision'].append(precision_score(y_test, y_pred, average='weighted', zero_division=0))
                outer_scores['recall'].append(recall_score(y_test, y_pred, average='weighted', zero_division=0))
                outer_scores['f1'].append(f1_score(y_test, y_pred, average='weighted', zero_division=0))
                outer_scores['roc_auc'].append(roc_auc_score(y_test, y_proba))
                outer_scores['mcc'].append(matthews_corrcoef(y_test, y_pred))

            # Tum dongulerden sonra en iyi hiperparametreleri sec ve modeli egit
            best_params_key = max(param_scores, key=lambda k: np.mean(param_scores[k]))
            best_params = eval(best_params_key)
            log_action(f"{model_name} icin tum CV sonrasi en iyi hiperparametreler: {best_params}")
            
            # En iyi hiperparametrelerle modeli bir kez egit ve kaydet
            X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
            best_model = load_or_train_model(model, best_params, X_train, y_train, X_val, y_val, model_filename)
            
            return {key: np.mean(value) for key, value in outer_scores.items()}, best_params
        except Exception as e:
            log_action(f"Hata alindi: {model_name} icin {feature_count} ozellik - {str(e)}. Grafik ve tablo islemleri devam ediyor...")
            return None, None

    # Ozellik secimi
    log_action(f"ANOVA F-score ile {n_features} ozellik secimi baslatiliyor...")
    X = data[[f'feature_{i}' for i in range(1, 29)]]
    y = data['target']
    try:
        selector = SelectKBest(score_func=f_classif, k=n_features)
        X_selected = selector.fit_transform(X, y)
        selected_features = [features[i] for i in selector.get_support(indices=True)]
        log_action(f"Secilen {n_features} ozellik: {selected_features}")
    except Exception as e:
        log_action(f"Ozellik secimi hatasi: {e}. Islem durduruluyor.")
        return {}

    data_before_feature_selection = data.copy()
    data_selected = data[['target'] + selected_features]
    log_action(f"Secilmis {n_features} ozellikli veri seti olusturuldu.")

    # Sadece secilen ozellikler icin gorsellestirme
    for feature in selected_features[:15]:
        plot_before_after(data_before_feature_selection, data_selected, feature, f'feature_selection_{n_features}')

    # Model egitimi ve degerlendirme
    X = data_selected.drop('target', axis=1).values
    y = data_selected['target'].values

    results = {}
    best_params_dict = {}
    log_action(f"{n_features} ozellik ile {model_name} icin Nested CV basliyor...")
    model = models[model_name]
    try:
        result, best_params = nested_cv(X, y, model, param_grids[model_name], n_features, model_name)
        if result is not None:
            results[model_name] = result
            if best_params:
                best_params_dict[model_name] = best_params
    except Exception as e:
        log_action(f"Hata alindi: {model_name} icin {n_features} ozellik - {str(e)}. Grafik ve tablo islemleri devam ediyor...")

    # Grafikleri ciz (hata olsa bile)
    model_filename = f'{model_name.lower()}_model_{n_features}.pkl'
    plot_model_graphs(model_name, n_features, X, y, model_filename)

    # Sonuclari tablo olarak yazdir ve kaydet
    if results:
        log_action(f"{n_features} ozellik icin model performans sonuclari tablo olarak hazirlanacak...")
        results_df = pd.DataFrame(results).T
        print(f"\n{n_features} Ozellik ile Model Performans Tablosu:")
        print(results_df)
        results_df.to_csv(f'model_performance_table_{n_features}_{model_name}.csv')
        log_action(f"{n_features} ozellik ile model performans tablosu 'model_performance_table_{n_features}_{model_name}.csv' olarak kaydedildi.")

    log_action(f"{n_features} ozellik ile {model_name} modeli tamamlandi.")
    return results

# Tum modeller icin toplu grafikler
def plot_all_models(feature_counts, models, data, features):
    for k in feature_counts:
        log_action(f"{k} ozellik icin toplu grafikler olusturuluyor...")
        X = data[[f'feature_{i}' for i in range(1, 29)]]
        y = data['target']
        try:
            selector = SelectKBest(score_func=f_classif, k=k)
            X_selected = selector.fit_transform(X, y)
            selected_features = [features[i] for i in selector.get_support(indices=True)]
            data_selected = data[['target'] + selected_features]
            X = data_selected.drop('target', axis=1).values
            y = data_selected['target'].values
        except Exception as e:
            log_action(f"Toplu grafikler icin ozellik secimi hatasi: {e}. Grafik cizimi atlaniyor.")
            continue

        # Toplu ROC egrileri
        roc_all_file = f'roc_curves_{k}_features.png'
        if not os.path.exists(roc_all_file):
            log_action(f"{roc_all_file} bulunamadi, toplu ROC egrisi ciziliyor...")
            plt.figure(figsize=(10, 6))
            for name in models.keys():
                model_filename = f'{name.lower()}_model_{k}.pkl'
                if os.path.exists(model_filename):
                    log_action(f"{model_filename} bulundu, model yukleniyor...")
                    best_model = joblib.load(model_filename)
                    try:
                        fpr, tpr, _ = roc_curve(y, best_model.predict_proba(X)[:, 1])
                        plt.plot(fpr, tpr, label=f'{name} (AUC = {roc_auc_score(y, best_model.predict_proba(X)[:, 1]):.4f})')
                    except Exception as e:
                        log_action(f"{name} icin ROC egrisi hatasi: {e}")
                else:
                    log_action(f"{model_filename} bulunamadi, grafik icin model mevcut degil.")
            plt.plot([0, 1], [0, 1], 'k--')
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')
            plt.title(f'ROC Curves for All Models ({k} Features)')
            plt.legend()
            plt.savefig(roc_all_file)
            plt.close()
            log_action(f"{roc_all_file} kaydedildi.")
        else:
            log_action(f"{roc_all_file} bulundu, toplu ROC egrisi atlaniyor...")

        # Toplu Precision-Recall egrileri
        pr_all_file = f'pr_curves_{k}_features.png'
        if not os.path.exists(pr_all_file):
            log_action(f"{pr_all_file} bulunamadi, toplu Precision-Recall egrisi ciziliyor...")
            plt.figure(figsize=(10, 6))
            for name in models.keys():
                model_filename = f'{name.lower()}_model_{k}.pkl'
                if os.path.exists(model_filename):
                    log_action(f"{model_filename} bulundu, model yukleniyor...")
                    best_model = joblib.load(model_filename)
                    try:
                        precision, recall, _ = precision_recall_curve(y, best_model.predict_proba(X)[:, 1])
                        plt.plot(recall, precision, label=f'{name} (AUC-PR = {roc_auc_score(y, best_model.predict_proba(X)[:, 1]):.4f})')
                    except Exception as e:
                        log_action(f"{name} icin Precision-Recall egrisi hatasi: {e}")
                else:
                    log_action(f"{model_filename} bulunamadi, grafik icin model mevcut degil.")
            plt.xlabel('Recall')
            plt.ylabel('Precision')
            plt.title(f'Precision-Recall Curves for All Models ({k} Features)')
            plt.legend()
            plt.savefig(pr_all_file)
            plt.close()
            log_action(f"{pr_all_file} kaydedildi.")
        else:
            log_action(f"{pr_all_file} bulundu, toplu Precision-Recall egrisi atlaniyor...")

        # Bireysel Confusion Matrix ve diger grafikler
        for name in models.keys():
            model_filename = f'{name.lower()}_model_{k}.pkl'
            plot_model_graphs(name, k, X, y, model_filename)

# Ana program
if __name__ == "__main__":
    log_action("Proje baslatiliyor...")
    print(os.listdir('C:/Users/tcsekoc/Desktop/UU/ML/Ödev/Final/'))

    # Veri on isleme
    data, features = preprocess_data()

    # Modeller ve ozellik sayilari
    models = {
        'KNN': KNeighborsClassifier,
        'SVM': SVC,
        'MLP': MLPClassifier,
        'XGBoost': XGBClassifier
    }
    feature_counts = [12, 13, 15]

    # Tamamlanmamis kombinasyonlari bul
    all_results = {}
    for k in feature_counts:
        all_results[k] = {}
        for name in models.keys():
            model_filename = f'{name.lower()}_model_{k}.pkl'
            if os.path.exists(model_filename):
                log_action(f"{model_filename} bulundu, {name} icin {k} ozellik tamamlanmis, atlaniyor...")
                # Performans tablosunu yukle
                table_filename = f'model_performance_table_{k}_{name}.csv'
                if os.path.exists(table_filename):
                    results_df = pd.read_csv(table_filename, index_col=0)
                    all_results[k][name] = results_df.loc[name].to_dict()
                # Grafikleri ciz
                X = data[[f'feature_{i}' for i in range(1, 29)]]
                y = data['target']
                try:
                    selector = SelectKBest(score_func=f_classif, k=k)
                    X_selected = selector.fit_transform(X, y)
                    selected_features = [features[i] for i in selector.get_support(indices=True)]
                    data_selected = data[['target'] + selected_features]
                    X = data_selected.drop('target', axis=1).values
                    y = data_selected['target'].values
                    plot_model_graphs(name, k, X, y, model_filename)
                except Exception as e:
                    log_action(f"{name} icin {k} ozellik grafik cizimi hatasi: {e}")
            else:
                log_action(f"{model_filename} bulunamadi, {name} icin {k} ozellik calistirilacak...")
                results = run_model(name, k, data, features)
                if results:
                    all_results[k].update(results)

        # Tum modeller icin toplu grafikler
        plot_all_models([k], models, data, features)

        # Tum sonuclari birlestir ve kaydet
        if all_results[k]:
            log_action(f"{k} ozellik icin tum modellerin performans tablosu birlestiriliyor...")
            results_df = pd.DataFrame(all_results[k]).T
            print(f"\n{k} Ozellik ile Model Performans Tablosu:")
            print(results_df)
            results_df.to_csv(f'model_performance_table_{k}.csv')
            log_action(f"{k} ozellik ile tum modellerin performans tablosu 'model_performance_table_{k}.csv' olarak kaydedildi.")

    log_action("Proje tamamlandi. Tum loglar 'log.txt' dosyasina kaydedildi.")